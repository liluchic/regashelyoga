angular.module('app.controllers', [])
  
.controller('page3Ctrl', function($scope) {

})
   
.controller('page8Ctrl', function($scope) {

})
   
.controller('page9Ctrl', function($scope) {

})
   
.controller('page10Ctrl', function($scope) {

})
         
.controller('page11Ctrl', function($scope) {

})
   
.controller('page12Ctrl', function($scope) {

})
   
.controller('page13Ctrl', function($scope) {

})
  .controller('copypage11Ctrl', function($scope) {

  })
