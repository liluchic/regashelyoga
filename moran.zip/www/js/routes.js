angular.module('app.routes', ['ionicUIRouter'])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider



      /*
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.page3'
      2) Using $state.go programatically:
        $state.go('tabsController.page3');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab3/page1
      /page1/tab1/page1
  */
  .state('tabsController.page3', {
    url: '/page1',
    views: {
      'tab3': {
        templateUrl: 'templates/page3.html',
        controller: 'page3Ctrl'
      },
      'tab1': {
        templateUrl: 'templates/page3.html',
        controller: 'page3Ctrl'
      }
    }
  })

  .state('tabsController.page8', {
    url: '/page2',
    views: {
      'tab2': {
        templateUrl: 'templates/page8.html',
        controller: 'page8Ctrl'
      }
    }
  })

  .state('tabsController.page9', {
    url: '/page3',
    views: {
      'tab4': {
        templateUrl: 'templates/page9.html',
        controller: 'page9Ctrl'
      }
    }
  })

  .state('tabsController.page10', {
    url: '/page4',
    views: {
      'tab3': {
        templateUrl: 'templates/page10.html',
        controller: 'page10Ctrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  /*
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.page11'
      2) Using $state.go programatically:
        $state.go('tabsController.page11');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab3/page11
      /page1/tab1/page11
  */
  .state('tabsController.page11', {
    url: '/page11',
    views: {
      'tab3': {
        templateUrl: 'templates/page11.html',
        controller: 'page11Ctrl'
      },
      'tab1': {
        templateUrl: 'templates/page11.html',
        controller: 'page11Ctrl'
      }
    }
  })

  .state('tabsController.page12', {
    url: '/page12',
    views: {
      'tab4': {
        templateUrl: 'templates/page12.html',
        controller: 'page12Ctrl'
      }
    }
  })

  .state('page13', {
    url: '/page5',
    templateUrl: 'templates/page13.html',
    controller: 'page13Ctrl'
  })

    .state('tabsController.copypage11', {
      url: '/copypage11',
      views: {
        'tab3': {
          templateUrl: 'templates/copypage11.html',
          controller: 'copypage11Ctrl'
        },
        'tab1': {
          templateUrl: 'templates/copypage11.html',
          controller: 'copypage11Ctrl'
        }
      }
    })
$urlRouterProvider.otherwise('/page1/tab1/page1')



});
